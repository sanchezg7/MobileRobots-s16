#ifndef __irDist_h
#define __irDist_h



int computeDistance_SIR(int value);

#endif